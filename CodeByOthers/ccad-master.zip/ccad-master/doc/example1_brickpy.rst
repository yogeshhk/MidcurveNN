brick.py
========

Now that I'm satisfied with my brick, I'll place the ipython code in a
function in **brick.py**.  I'll call the function **brick** and pass **xsize**
and **ysize** as parameters.  I'll also make the fillets an option.
**brick.py** now looks like this:

.. include:: brick.py
  :literal:
