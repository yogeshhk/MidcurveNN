Displaying
==========

You have your model in text.  Now you want to see it.  The ccad viewer
can be run stand-alone or interactively.

.. toctree::
   :maxdepth: 2

   stand_alone
   interactive
   using_display
   controlling_display
   configuring_display

