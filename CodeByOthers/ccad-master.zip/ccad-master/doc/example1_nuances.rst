Nuances
=======

While the building toy example appears to be a step-by-step smooth
process, in reality, it wasn't.  OCC often has trouble with fillets
and boolean operations.  I had to play with the model and fillets
before I had something which worked robustly.  I originally included
those trails-to-nowhere to help you see how they can be overcome, but
it became over-complicated.  I removed them, and it looks simple now.
