Contents
========

.. toctree::
   :maxdepth: 2

   intro
   details
   modelling
   displaying
   example1
